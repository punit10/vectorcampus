<?php
$con = mysqli_connect("localhost", "root", "java@123", "punit")
or die('Database Not Connected. Please Fix the Issue! ' . mysql_error());
?>